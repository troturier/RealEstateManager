package com.openclassrooms.realestatemanager.database.dao;

import com.openclassrooms.realestatemanager.models.PointInteret;

import java.util.List;

import android.arch.lifecycle.LiveData;
import android.arch.persistence.room.Dao;
import android.arch.persistence.room.Insert;
import android.arch.persistence.room.Query;
import android.arch.persistence.room.Update;

@Dao
public interface PointInteretDao {
    @Query("SELECT * FROM PointInteret WHERE idBien = :idBien")
    LiveData<List<PointInteret>> getPointInterets(int idBien);

    @Query("SELECT * FROM PointInteret WHERE id = :id")
    LiveData<PointInteret> getPointInteret(int id);

    @Insert
    long insertPointInteret(PointInteret pointInteret);

    @Update
    int updatePointInteret(PointInteret pointInteret);

    @Query("DELETE FROM PointInteret WHERE id = :pointInteretId")
    int deletePointInteret(int pointInteretId);
}
