package com.openclassrooms.realestatemanager.database.dao;

import com.openclassrooms.realestatemanager.models.Type;

import java.util.List;

import android.arch.lifecycle.LiveData;
import android.arch.persistence.room.Dao;
import android.arch.persistence.room.Insert;
import android.arch.persistence.room.Query;
import android.arch.persistence.room.Update;

@Dao
public interface TypeDao {
    @Query("SELECT * FROM Type")
    LiveData<List<Type>> getTypes();

    @Query("SELECT * FROM Type WHERE id = :id")
    LiveData<Type> getType(int id);

    @Insert
    long insertType(Type type);

    @Update
    int updateType(Type type);

    @Query("DELETE FROM Type WHERE id = :typeId")
    int deleteType(int typeId);
}
