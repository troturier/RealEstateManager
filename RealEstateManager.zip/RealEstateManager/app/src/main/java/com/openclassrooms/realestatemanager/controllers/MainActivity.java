package com.openclassrooms.realestatemanager.controllers;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

import com.openclassrooms.realestatemanager.R;
import com.openclassrooms.realestatemanager.database.RealEstateManagerDatabase;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        RealEstateManagerDatabase database = RealEstateManagerDatabase.getInstance(this);

    }

}
